package ca.qc.bdeb.inf203.TP2;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

import java.util.ArrayList;

public class Particule extends EntiteQuiBouge {
    private Color couleur;

    private final int rayon = 5;
    private double ax, ay;
    private final double k = 30;
    private final double q1 = 10;
    private double forceEnX;
    private double forceEnY;

    public Particule(double x, double y, Color couleur) {
        this.couleur = couleur;
        this.x = x;
        this.y = y;
    }

    public void draw(GraphicsContext context, double bouleMagiqueX, double bouleMagiqueY) {
        context.fillOval(
                bouleMagiqueX+x,
                bouleMagiqueY+y,
                2 * rayon, 2 * rayon);
        context.setFill(couleur);
    }
    public void setCouleur(Color couleur) {
        this.couleur = couleur;
    }

    public void loiDeCoulomb(ArrayList<Particule> tabToutesParticules) {
        double forceElectrique = 0;
        for (int i = 0; i < tabToutesParticules.size(); i++) {
            double deltaX = x-tabToutesParticules.get(i).x;
            double deltaY = y-tabToutesParticules.get(i).y;
            double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
            if (distance < 0.01)
                distance = 0.01;
            double proportionY = deltaY / distance;
            double proportionX = deltaX / distance;
            forceElectrique += ((k * q1 * q1) / distance);
            forceEnX = forceElectrique*proportionX;
            forceEnY = forceElectrique*proportionY;
        }
    }

//    public void calculAcceleration() {
//        return forceElectrique();
//    }


    public void updatePhysique(double dt) {
        ax = forceEnX*1e-3;
        ay = forceEnY*1e-3;
        vx += dt * ax;
        vy += dt * ay;
        x += dt * vx;
        y += dt * vy;

        // Valide que la balle ne termine jamais hors des côtés de l'écran
        x = Math.min(x, MainJavaFX.WIDTH - rayon);
        x = Math.max(x, rayon);
        y = Math.min(y, MainJavaFX.HEIGHT - rayon);
        y = Math.max(y, rayon);
    }

    public void update(double dt) {
        updatePhysique(dt);
        if (x * x + y * y >= 35 * 35) {
            x = 0;
            y = 0;
            ay = 0;
            ax = 0;
            vx = 0;
            vy = 0;
        }
        if (vx < -50)
            vx = -50;
        if (vx > 50)
            vx = 50;
        vy += dt * ay;
        if (vy < -50)
            vy = -50;
        if (vy > 50)
            vy = 50;
    }
}
