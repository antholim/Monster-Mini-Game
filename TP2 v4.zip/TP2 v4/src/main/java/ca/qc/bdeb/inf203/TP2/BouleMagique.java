package ca.qc.bdeb.inf203.TP2;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;

import java.util.ArrayList;

public class BouleMagique extends EntiteQuiBouge {
    private Color couleur;
    private double timer;
    private ArrayList<BouleMagique> tabBoulesMagiques = new ArrayList<>();
    private boolean enContact;
    private boolean dessiner = false;
    private boolean estRecharge;
    private final int rayon = 35;

    private final double circonference = 2 * Math.PI * rayon;
    private ArrayList<Particule> tabParticulesAutourBoule = new ArrayList<>();
    private ArrayList<Particule> tabParticuleVisibles = new ArrayList<>();
    private ArrayList<Particule> tabToutesParticules = new ArrayList<>();
    private final double tempsDeRecharge = 0.6;

    public BouleMagique(double x, double y) {
        this.x = x;
        this.y = y ;
        this.vy = -300;
//        this.couleur = couleurRandom();

        initialisationTableauParticules();
    }
    public double particulesXAutourCercle(int compteur){
        double degresParParticule = (2 * Math.PI)/100;//360 degres divises par 100 particules
        double x= 0;
        for (int i = 0; i<100; i++)
            x = rayon*Math.cos(degresParParticule*compteur);
        return x;
    }
    public double particulesYAutourCercle(int compteur){
        double degresParParticule = (2 * Math.PI)/100;//360 degres divises par 100 particules
        double y = 0;
        y = rayon*Math.sin(degresParParticule*compteur);
        return y;
    }
    public double randomX_Particule() {
        if (Math.random() > 0.5) return (Math.random() * rayon);
        else return -Math.random() * rayon;
    }

    public double randomY_Particule(double valeurX) {
        double maxY = Math.sqrt((rayon) * (rayon) - valeurX * valeurX);
        if (Math.random() > 0.5) return Math.random() * maxY;
        else return -Math.random() * maxY;
    }

    public void initialisationTableauParticules() {
        couleur = couleurRandom();
        for (int i = 0; i < 100; i++) {
            double valeurX = randomX_Particule();
            Particule particule = new Particule(particulesXAutourCercle(i), particulesYAutourCercle(i),couleur);
            tabParticulesAutourBoule.add(particule);//retourner en parametres valeurX d'une particule autour sur la circonference cercle, pour l'instant retourner random x/y
            tabToutesParticules.add(particule);
        }
        for (int i = 0; i < 15; i++) {
            double valeurX = randomX_Particule();
            Particule particule = new Particule(valeurX, randomY_Particule(valeurX), couleur);
            tabParticuleVisibles.add(particule);//retourner en parametres valeurX d'une particule autour sur la circonference cercle, pour l'instant retourner random x/y
            tabToutesParticules.add(particule);
        }
    }

    public void update(double deltaTemps) {
        timer = timer + deltaTemps;
        y += deltaTemps * vy;
        for (int i = 0; i < tabToutesParticules.size(); i++) {
            tabToutesParticules.get(i).update(deltaTemps);
        }
        for (Particule particule : tabParticuleVisibles) {
            tabToutesParticules.remove(particule);
            particule.loiDeCoulomb(tabToutesParticules);
            tabToutesParticules.add(particule);
        }
    }
    public void draw(GraphicsContext context, double deltaTemps, Color color) {
        update(deltaTemps);
//        context.fillOval(x, y - rayon, 2 * rayon, 2 * rayon);
        for (Particule particule : tabParticuleVisibles) {
            particule.draw(context, x, y);
        }
    }

    public double getY() {
        return y;
    }

    public double getX() {
        return x;
    }

    public boolean etatDeCharge() {
//        estRecharge = true;
        if (timer > tempsDeRecharge) {
            estRecharge = true;
            timer = timer - 0.6;
        }
        return estRecharge;
    }
    public Color couleurRandom(){
        Color[]colors = {Color.BLUE,Color.GREEN,Color.RED,Color.ORANGE,Color.GOLD,Color.YELLOW,Color.PINK,Color.PURPLE,Color.ROYALBLUE};
        Color couleur = colors[rd.nextInt(colors.length)];
//        for (int i = 0; i < tabParticuleVisibles.size(); i++) {
//            System.out.println(couleur);
//            tabParticuleVisibles.get(i).setCouleur(couleur);
//        }
        return couleur;
    }
    public void lancerBouleMagique(double xSquelette, double ySquelette, GraphicsContext context, double deltaTemps) {
        update(deltaTemps);
        boolean estTiree = false;
        if (etatDeCharge()) {
            if (Input.isKeyPressed(KeyCode.SPACE)) {
                tabBoulesMagiques.add(new BouleMagique(xSquelette, ySquelette));
                dessiner = true;
                estTiree = true;
            }
        }
        if (estTiree) {
            estRecharge = false;
            timer = 0;
            couleurRandom();
        }
        if (dessiner) {
            for (int i = 0; i < tabBoulesMagiques.size(); i++) {
                if (tabBoulesMagiques.get(i).getY() > 0) tabBoulesMagiques.get(i).draw(context, deltaTemps, couleur);
            }
        }
    }

    public void enContact(Monstres monstre, Partie partie) {
        int tabBoulesMagiquesSize = tabBoulesMagiques.size();
        for (int i = 0; i < tabBoulesMagiquesSize; i++) {
            double dx = tabBoulesMagiques.get(i).getX() - monstre.getX();
            double dy = tabBoulesMagiques.get(i).getY() - monstre.getY();
            double dCarre = dx * dx + dy * dy;
            if (dCarre < 0) {
                dCarre = dCarre * -1;
            }
            if (dCarre < (this.rayon + monstre.getRayon()) * (this.rayon + monstre.getRayon())) enContact = true;
            else enContact = false;
            if (enContact) {
                partie.miseAJourScore(monstre);
                monstre.setEffacer(true);
            }
        }
    }
}