package ca.qc.bdeb.inf203.TP2;

import javafx.scene.image.Image;

public class Oeil extends Monstres{
    double timerOeil = 0;
    public Oeil(int niveau) {
        imageEntite = new Image("oeil.png");
        parametreOeil(niveau);
    }
    public void parametreOeil(int niveau) {
        positionInitial();
        //À changer
        vx = 100 * Math.pow(niveau, 0.33) + 200;
        directionInitial();
    }

    @Override
    public void update(double deltaTemps) {
        updatePhysique(deltaTemps);
        super.update(deltaTemps);
    }
    @Override
    public void updatePhysique(double deltaTemps) {
        timerOeil = timerOeil + deltaTemps;

        if (!sensPersonnage) {
            if (timerOeil > 0.5 && vx > 0) {
                vx = -vx;
            } else if (timerOeil > 0.75) {
                vx = -vx;
                timerOeil = timerOeil - 0.75;
            }
        } else {
            if (timerOeil > 0.5 && vx < 0) {
                vx = -vx;
            } else if (timerOeil > 0.75) {
                vx = -vx;
                timerOeil = timerOeil - 0.75;
            }
        }
    }
}

