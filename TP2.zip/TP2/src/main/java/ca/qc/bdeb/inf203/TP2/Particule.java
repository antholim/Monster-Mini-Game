package ca.qc.bdeb.inf203.TP2;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Particule {
    private int rayon = 5;
    private final double k = 30;
    private double q1 = 10, q2 = 10;
    private double distance, acceleration, vx, vy;
    private int x, y;

    private boolean estAInterieurBoule;

    private BouleMagique magie;

    public Particule() {

    }

    public void draw(GraphicsContext context) {
        context.fillRoundRect(
                x - rayon,
                y - rayon,
                2 * rayon, 2 * rayon, rayon, rayon);
        context.setFill(Color.color(Math.random(), Math.random(), Math.random()));
    }

    public void changerCouleur(GraphicsContext context) {
        context.setFill(Color.color(Math.random(), Math.random(), Math.random()));
    }

    public void calculDistance() {
        distance = Math.sqrt(x * x + y * y);
        if (distance < 0.01)
            distance = 0.01;
    }

    public double forceElectrique() {
        return 114 * ((k * q1 * q2) / distance * distance);
    }

    public void calculAcceleration() {
        acceleration = forceElectrique();
    }

    public void physique() {

    }

    public void update(double dt) {
        calculAcceleration();
        // Calcul de la nouvelle vitesse
        vx += dt * acceleration;
        if (vx < -50)
            vx = -50;
        if (vx > 50)
            vx = 50;
        vy += dt * acceleration;
        if (vy < -50)
            vy = -50;
        if (vy > 50)
            vy = 50;

        // Calcul de la nouvelle position
        x += dt * vx;
        y += dt * vy;
        //if (!estAInterieurBoule){
       // x = 0;
        //y = 0;
    //}
        //if (x + rayon > ca.qc.bdeb.inf203.TP2.MainJavaFX.WIDTH || x - rayon < 0) {
           // vx *= -0.9;
        //}
        //if (y + rayon > ca.qc.bdeb.inf203.TP2.MainJavaFX.HEIGHT || y - rayon < 0) {
           // vy *= -0.9;
        //}

        // Valide que la balle ne termine jamais hors des côtés de l'écran
        x = Math.min(x, ca.qc.bdeb.inf203.TP2.MainJavaFX.WIDTH - rayon);
        x = Math.max(x, rayon);
        y = Math.min(y, ca.qc.bdeb.inf203.TP2.MainJavaFX.HEIGHT - rayon);
        y = Math.max(y, rayon);
    }

}
