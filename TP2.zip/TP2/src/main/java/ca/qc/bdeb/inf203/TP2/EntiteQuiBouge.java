package ca.qc.bdeb.inf203.TP2;

import javafx.scene.image.Image;

public abstract class EntiteQuiBouge {
    protected double x, y;
    protected double w, h;
    protected double vx, vy;
    protected Image imageEntite;
    //True = Vers Gauche, False = Vers Droite
    protected boolean sensPersonnage;
    protected ImageHelpers imageHelpers = new ImageHelpers();
}

