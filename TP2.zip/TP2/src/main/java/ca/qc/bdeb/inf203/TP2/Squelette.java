package ca.qc.bdeb.inf203.TP2;

import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.canvas.GraphicsContext;

import java.util.ArrayList;

public class Squelette {
    private double x, y;
    private double w = 48;
    private double h = 96;
    private double vx, vy;
    private final double saut = 600;
    private double accelerationX;
    private double accelerationY = 1200;
    private boolean dansLesAirs = true;
    private final double vitesseMax = 300;
    private boolean sensSquelette;
    private int nbVies;

    public Squelette() {
        this.x = MainJavaFX.WIDTH/2;
        this.y = MainJavaFX.HEIGHT/2;
        this.vx = 0;
        this.sensSquelette = false;
        this.nbVies = 3;
        this.accelerationX = 0;
    }

    public void update(double deltaTemps) {
        updatePhysique();
        vy += deltaTemps * accelerationY;
        vx += deltaTemps * accelerationX;
        y += deltaTemps * vy;
        x += deltaTemps * vx;
    }

    public void updatePhysique() {
        if (y + h >= MainJavaFX.HEIGHT) {
            y = MainJavaFX.HEIGHT - h;
            vy = 0;
            dansLesAirs = false;
        } else {
            dansLesAirs = true;
        }
        if (!dansLesAirs)
            accelerationY = 0;
        else {
            accelerationY = 1200;
            accelerationX = 0;
        }

        if (x < 0) {
            x = 0;
            vx = -vx;
        } else if (x + w > MainJavaFX.WIDTH) {
            x = MainJavaFX.WIDTH - w;
            vx = -vx;
        }

        boolean left = Input.isKeyPressed(KeyCode.LEFT);
        boolean right = Input.isKeyPressed(KeyCode.RIGHT);
        boolean jump = Input.isKeyPressed(KeyCode.UP);

        if (left) {
            accelerationX = -1000;
        } else if (right) {
            accelerationX = 1000;
        } else {
            if (vx > 4)
                accelerationX = -200;
            else if (vx < -4)
                accelerationX = 200;
            else if (Math.abs(vx) <= 4) {
                vx = 0;
                accelerationX = 0;
            }
        }
        if (jump && !dansLesAirs) {
            vy = -saut;
        }

        if (vx >= vitesseMax)
            vx = vitesseMax;
        if (vx <= -vitesseMax)
            vx = -vitesseMax;
    }

    public void draw(GraphicsContext context, Image image) {
        ImageHelpers imageHelpers = new ImageHelpers();
        if (vx < 0) {
            sensSquelette = true;
        } else if (vx > 0) {
            sensSquelette = false;
        }
        if (sensSquelette) {
            image = imageHelpers.flop(image);
            context.drawImage(image, x, y, w, h);
        } else {
            context.drawImage(image, x, y, w, h);
        }
        //Image imageSquelette = new Image("stable.png");
        //context.setFill(new ImagePattern(imageSquelette));
        // if (vx < 0) {
        //imageSquelette = imageHelpers.flop(imageSquelette);
        //context.setFill(new ImagePattern(imageSquelette));
        //context.setFill(new ImagePattern(image));
        // }else if (vx > 0) {
//            imageSquelette = imageHelpers.flop(imageSquelette);
        //context.setFill(new ImagePattern(imageSquelette));
        // context.setFill(new ImagePattern(image));


        //       context.fillRect(x, y, w, h);
//        context.rect(100, 100, 48, 96);
//        context.setFill(Color.RED);
//        context.fillRect(MainJavaFX.WIDTH/2, MainJavaFX.HEIGHT/2, w, h);
        //  }
    }
    public void updateNbVies(Monstres monstres){
            if (monstres.aSurvecu())
                nbVies--;
    }
    public double getVx() {
        return vx;
    }

    public int getNbVies() {
        return nbVies;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }
}