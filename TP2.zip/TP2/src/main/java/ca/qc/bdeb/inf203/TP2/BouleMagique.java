package ca.qc.bdeb.inf203.TP2;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;

import java.util.ArrayList;

public class BouleMagique extends EntiteQuiBouge{
    private double timer;

    ArrayList<BouleMagique> tabBoulesMagiques = new ArrayList<>();

    private boolean estTiree;

    private boolean enContact;

    private boolean dessiner = false;
    private boolean estRecharge;
    private int rayon = 35;
    private ArrayList<Particule> tabParticules;
    private double tempsDeRecharge = 0.6;

    public BouleMagique(double x, double y) {
        this.x = x;
        this.y = y-rayon;
        this.vy = -300;
    }

    public void initialisationTableauParticules() {
        for (int i = 0; i < 15; i++)
            tabParticules.add(new Particule());
    }

    public void bouleMagique(GraphicsContext context) {
        initialisationTableauParticules();
        for (Particule particule : tabParticules) {
            particule.draw(context);
        }
    }

    public void update(double deltaTemps) {
        timer += timer+deltaTemps;
        y +=deltaTemps * vy;
    }

    public void draw(GraphicsContext context,double deltaTemps) {
        update(deltaTemps);
            context.fillOval(
                    x,
                    y - rayon,
                    2 * rayon, 2 * rayon);
    }
    public double getY() {
        return y;
    }
    public double getX(){
        return x;
    }
    public boolean etatDeCharge(){
        if (timer/tempsDeRecharge >= 1)
            estRecharge = true;
        return estRecharge;
    }
    public void lancerBouleMagique(double xSquelette,double ySquelette,GraphicsContext context,double deltaTemps){
        update(deltaTemps);
        boolean estTiree = false;
        System.out.println(Input.isKeyPressed(KeyCode.SPACE));
        if (etatDeCharge()){
            if (Input.isKeyPressed(KeyCode.SPACE)) {
                tabBoulesMagiques.add(new BouleMagique(xSquelette,ySquelette));
                dessiner = true;
                estTiree = true;
            }
            }if (estTiree) {
            estRecharge = false;
            timer = 0;
        }
        if (dessiner)
            for (int i = 0; i<tabBoulesMagiques.size(); i++){
                if (tabBoulesMagiques.get(i).getY()>0)
                    tabBoulesMagiques.get(i).draw(context,deltaTemps);
            }
    }
        public void enContact(Monstres monstre,GraphicsContext context,Partie partie){
        for (BouleMagique bouleMagique:tabBoulesMagiques) {
            double dx = bouleMagique.x - monstre.getX();
            double dy = bouleMagique.y - monstre.getY();
            double dCarre = dx * dx + dy * dy;
            if (dCarre < (this.rayon + monstre.getRayon()) * (this.rayon + monstre.getRayon()))
                enContact = true;
            else enContact = false;
            if (enContact) {
                partie.miseAJourScore(monstre);
            }
        }


        }

}
