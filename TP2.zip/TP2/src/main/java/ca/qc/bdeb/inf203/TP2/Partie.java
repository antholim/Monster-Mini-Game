package ca.qc.bdeb.inf203.TP2;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

public class Partie {
    private int niveau;
    private int score;
    private boolean estFinie;

    public Partie() {
        this.estFinie = false;
    }

    public void miseAJourNiveau() {
        niveau = score / 5;
    }

    public void miseAJourScore(Monstres monstres) {
        monstres.estMort();
            score++;
    }

    public void miseAJourJeu(int nbVies) {
        miseAJourNiveau();
        estFinie(nbVies);
    }

    public void estFinie(int nbVies) {
        if (nbVies == 0)
            estFinie = true;
    }

    public boolean isEstFinie() {
        return estFinie;
    }

    public void drawTetesMort(GraphicsContext context,int nbVies) {
        ImageHelpers imageHelpers = new ImageHelpers();
        Image image = new Image("squelette.png");
        image = imageHelpers.colorize(image,Color.PINK);
        int nombre = 75;
        int nombre2 = 0;
        for (int i = 0; i<nbVies; i++) {
            nombre2+=30;
            context.drawImage(image, MainJavaFX.WIDTH / 2 - nombre +nombre2, 150,30,30);
        }
        System.out.println(nbVies);
        //context.fillText(text,MainJavaFX.WIDTH/3,MainJavaFX.HEIGHT/2);
    }
    public void drawNiveau(GraphicsContext context){
        context.fillText("NIVEAU "+getNiveau(),MainJavaFX.WIDTH/2,MainJavaFX.HEIGHT/2,MainJavaFX.WIDTH-200);
        context.setFont(Font.font(30));
        context.setTextAlign(TextAlignment.CENTER);
    }
    public void drawScore(GraphicsContext context){
        context.fillText(String.valueOf(getScore()),MainJavaFX.WIDTH/2,100,MainJavaFX.WIDTH-200);
        context.setFont(Font.font(10));
        context.setTextAlign(TextAlignment.CENTER);
    }
    public void draw(GraphicsContext context,int nbVies){
        drawScore(context);
        drawNiveau(context);
        drawTetesMort(context,nbVies);
        context.setFill(Color.WHITE);
    }

    public void setEstFinie(boolean estFinie) {
        this.estFinie = estFinie;
    }

    public int getNiveau() {
        return niveau;
    }

    public void setNiveau(int niveau) {
        this.niveau = niveau;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
