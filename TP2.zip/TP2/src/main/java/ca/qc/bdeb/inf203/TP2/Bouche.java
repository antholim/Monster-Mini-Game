package ca.qc.bdeb.inf203.TP2;

import javafx.scene.image.Image;

public class Bouche extends Monstres {
    private double tempsEcoule = 0;
    private double yBase;
    public Bouche() {
        imageEntite = new Image("bouche.png");
        parametreBouche();


    }
    public void parametreBouche() {
        positionInitial();
        //Vitesse à changer pour les monstres différents
        vx = 1.3 * (100 * Math.pow(numeroNiveau, 0.33) + 200);

        directionInitial();
    }

    @Override
    public void update(double deltaTemps) {
        super.update(deltaTemps);
        updatePhysique(deltaTemps);
    }
    @Override
    public void updatePhysique(double deltaTemps) {
        tempsEcoule += deltaTemps;
        y = yBase + 50 * Math.sin(10 * tempsEcoule);
    }
}


