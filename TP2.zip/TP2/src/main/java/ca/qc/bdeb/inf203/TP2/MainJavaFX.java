package ca.qc.bdeb.inf203.TP2;


import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.ArrayList;

public class MainJavaFX extends Application {
    Scene sceneEcranAccueil;
    public static String[] imageMarche = {"marche1.png", "marche2.png"};
    public static final int WIDTH = 640;
    public static final int HEIGHT = 480;
    public static final int nbSecondesAffichageNiveau = 3;
    private BackgroundFill fondNoir = new BackgroundFill(Color.BLACK, new CornerRadii(1),
            new Insets(0.0, 0.0, 0.0, 0.0));

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        var vbox = new VBox();
        vbox.setBackground(new Background(fondNoir));
        vbox.setId("vbox");
        vbox.setAlignment(Pos.CENTER);
        vbox.setSpacing(25);
        ImageView imageView = new ImageView(new Image("logo.png"));
        imageView.setFitHeight(HEIGHT - 150);
        imageView.setFitWidth(WIDTH - 200);
        var btnJouer = new Button("Jouer !");
        var btnInfos = new Button("Infos");
        var btnRetour = new Button("Retour");
        sceneEcranAccueil = new Scene(vbox, WIDTH, HEIGHT);


        vbox.getChildren().addAll(imageView, btnJouer, btnInfos);

        sceneEcranAccueil.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ESCAPE)
                Platform.exit();
        });

        btnInfos.setOnAction(event -> {
            primaryStage.setScene(sceneInfos(btnRetour, primaryStage));
        });
        btnRetour.setOnAction(event -> {
            primaryStage.setScene(sceneEcranAccueil);
        });
        btnJouer.setOnAction(event -> {
            primaryStage.setScene(sceneJouer(primaryStage));
        });
        primaryStage.setTitle("Squelette Espiegle");
        primaryStage.setScene(sceneEcranAccueil);
        primaryStage.show();
    }

    public Scene sceneInfos(Button btn, Stage stage) {
        var root = new VBox();
        Text titreDuJeu = new Text("Squelette Espiègle");
        titreDuJeu.setFont(Font.font(36));

        //Deuxième boîte
        Text par = new Text("Par");
        Text et = new Text("et");
        par.setFont(Font.font(24));
        et.setFont(Font.font(24));
        var createur1 = new HBox();
        var createur2 = new HBox();
        Text nom1 = new Text(" Anthony Lim");
        Text nom2 = new Text(" Hugo Galvao Valente");
        nom1.setFill(Color.GREEN);
        nom2.setFill(Color.RED);
        nom1.setFont(Font.font(24));
        nom2.setFont(Font.font(24));
        createur1.getChildren().addAll(par, nom1);
        createur2.getChildren().addAll(et, nom2);
        createur1.setAlignment(Pos.CENTER);
        createur2.setAlignment(Pos.CENTER);
        Text ligne1 = new Text("Travail remis à Nicolas Hurtbuise. Graphismes adaptés de");
        Text ligne2 = new Text("https://game-icons.net/. Développé dans le cadre du cours 420-203-RE");
        Text ligne3 = new Text("Développement de programmes dans un environnement graphique, au");
        Text ligne4 = new Text("Collège de Bois-de-Boulogne");
        root.getChildren().addAll(titreDuJeu, createur1, createur2, ligne1, ligne2, ligne3, ligne4, btn);
        root.setAlignment(Pos.CENTER);
//        Image imageLogo = new Image("mots.png");
//        ImageView imageLogoView = new ImageView(imageLogo);

        Scene sceneInfos = new Scene(root, WIDTH, HEIGHT);
        sceneInfos.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ESCAPE)
                stage.setScene(sceneEcranAccueil);
        });
        return sceneInfos;
    }

    public Scene sceneJouer(Stage stage) {
        var pane = new Pane();
        pane.setBackground(new Background(fondNoir));
        Scene sceneJeu = new Scene(pane, WIDTH, HEIGHT);
        var canvas = new Canvas(WIDTH, HEIGHT);
        var context = canvas.getGraphicsContext2D();
        var monstre = new MonstresNormaux();
        var bouche = new Bouche();
        var oeil = new Oeil();
        var squelette = new Squelette();
        ArrayList<Monstres> monstres = new ArrayList<>();
        monstres.add(oeil);
        monstres.add(monstre);
        BouleMagique bouleMagique = new BouleMagique(squelette.getX(),squelette.getY());
        Partie partie = new Partie();
        //Magie magie = new Magie(squelette.getX(),squelette.getY());

        var timer = new AnimationTimer() {
            long lastTime = System.nanoTime();
            double frameRate = 10 * 1e-9;
            boolean continuer = false;

            @Override
            public void handle(long now) {
                double deltaTemps = (now - lastTime) * 1e-9;
                context.clearRect(0, 0, WIDTH, HEIGHT);
                int frame = (int) Math.floor((deltaTemps * frameRate) * 1e12);
                for (Monstres monstre : monstres) {
                    monstre.update(deltaTemps);
                    monstre.draw(context);
                }
                bouleMagique.lancerBouleMagique(squelette.getX(),squelette.getY(),context,deltaTemps);
                for (Monstres monstre:monstres) {
                    bouleMagique.enContact(monstre, context, partie);
                    squelette.updateNbVies(monstre);
                }
                squelette.update(deltaTemps);
                squelette.draw(context, new Image("stable.png"));
                if (Math.abs(squelette.getVx()) > 0) {
                    squelette.draw(context, new Image(imageMarche[(frame % imageMarche.length)]));
                }
                partie.miseAJourJeu(squelette.getNbVies());
                partie.draw(context, squelette.getNbVies());

                lastTime = now;
            }
        };
        timer.start();
        sceneJeu.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ESCAPE) {
                stage.setScene(sceneEcranAccueil);
            } else {
                Input.setKeyPressed(event.getCode(), true);
            }
        });
        sceneJeu.setOnKeyReleased((e) -> {
            Input.setKeyPressed(e.getCode(), false);
        });
        pane.getChildren().addAll(canvas);
        return sceneJeu;
    }

}

